package com.iamnotplaying.farmersrework.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.CropBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.Items;

import java.util.function.Supplier;

public class FarmCropBlock extends CropBlock {
    public static final MapCodec<FarmCropBlock> CODEC = createCodec(s -> new FarmCropBlock(s, () -> Items.WHEAT_SEEDS));
    private final Supplier<Item> seeds;

    public FarmCropBlock(Settings settings, Supplier<Item> seeds) {
        super(settings);
        this.seeds = seeds;
    }

    @Override
    public MapCodec<? extends CropBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected ItemConvertible getSeedsItem() {
        return seeds.get();
    }

    public Item seed() {
        return seeds.get();
    }
}
