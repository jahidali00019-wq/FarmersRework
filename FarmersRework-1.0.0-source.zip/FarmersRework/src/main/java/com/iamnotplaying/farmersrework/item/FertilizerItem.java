package com.iamnotplaying.farmersrework.item;

import net.minecraft.block.BlockState;
import net.minecraft.block.CropBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldEvents;

/** Rich Fertilizer: grows all crops in a 3x3 area by a lot. */
public class FertilizerItem extends Item {
    public FertilizerItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World world = ctx.getWorld();
        BlockPos origin = ctx.getBlockPos();
        boolean any = false;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                BlockPos pos = origin.add(dx, 0, dz);
                BlockState st = world.getBlockState(pos);
                if (st.getBlock() instanceof CropBlock crop && !crop.isMature(st)) {
                    any = true;
                    if (!world.isClient) {
                        crop.applyGrowth(world, pos, st);
                        BlockState st2 = world.getBlockState(pos);
                        if (st2.getBlock() instanceof CropBlock c2 && !c2.isMature(st2)) {
                            c2.applyGrowth(world, pos, st2);
                        }
                        world.syncWorldEvent(WorldEvents.BONE_MEAL_USED, pos, 15);
                    }
                }
            }
        }
        if (!any) return ActionResult.PASS;
        if (!world.isClient) ctx.getStack().decrementUnlessCreative(1, ctx.getPlayer());
        return ActionResult.success(world.isClient);
    }
}
