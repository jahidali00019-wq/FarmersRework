package com.iamnotplaying.farmersrework;

import com.google.common.collect.ImmutableSet;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.SoundEvents;
import net.minecraft.village.VillagerProfession;
import net.minecraft.world.poi.PointOfInterestType;

public class ModVillagers {
    public static final RegistryKey<PointOfInterestType> ORCHARDIST_POI =
            RegistryKey.of(RegistryKeys.POINT_OF_INTEREST_TYPE, FarmersRework.id("orchardist_poi"));
    public static VillagerProfession ORCHARDIST;

    public static void init() {
        PointOfInterestHelper.register(FarmersRework.id("orchardist_poi"), 1, 1, ModBlocks.FRUIT_CRATE);
        ORCHARDIST = Registry.register(Registries.VILLAGER_PROFESSION, FarmersRework.id("orchardist"),
                new VillagerProfession("orchardist",
                        entry -> entry.matchesKey(ORCHARDIST_POI),
                        entry -> entry.matchesKey(ORCHARDIST_POI),
                        ImmutableSet.of(), ImmutableSet.of(),
                        SoundEvents.ENTITY_VILLAGER_WORK_FARMER));
    }
}
