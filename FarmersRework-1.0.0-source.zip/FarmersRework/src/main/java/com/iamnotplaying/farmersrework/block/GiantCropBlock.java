package com.iamnotplaying.farmersrework.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

import java.util.function.Supplier;

/** A crop that, once fully grown, turns into a giant (full) block. */
public class GiantCropBlock extends FarmCropBlock {
    public static final MapCodec<GiantCropBlock> CODEC = createCodec(
            s -> new GiantCropBlock(s, () -> Items.PUMPKIN_SEEDS, () -> Blocks.PUMPKIN));
    private final Supplier<Block> grown;

    public GiantCropBlock(Settings settings, Supplier<Item> seeds, Supplier<Block> grown) {
        super(settings, seeds);
        this.grown = grown;
    }

    @Override
    public MapCodec<? extends CropBlock> getCodec() {
        return CODEC;
    }

    @Override
    public void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        super.randomTick(state, world, pos, random);
        convert(world, pos);
    }

    @Override
    public void applyGrowth(World world, BlockPos pos, BlockState state) {
        super.applyGrowth(world, pos, state);
        convert(world, pos);
    }

    private void convert(World world, BlockPos pos) {
        BlockState s = world.getBlockState(pos);
        if (s.isOf(this) && isMature(s)) {
            world.setBlockState(pos, grown.get().getDefaultState());
        }
    }
}
