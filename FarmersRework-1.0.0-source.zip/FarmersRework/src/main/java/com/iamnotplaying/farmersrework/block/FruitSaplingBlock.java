package com.iamnotplaying.farmersrework.block;

import com.iamnotplaying.farmersrework.FarmersRework;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;
import net.minecraft.world.gen.feature.ConfiguredFeature;

import java.util.Optional;

public class FruitSaplingBlock extends PlantBlock implements Fertilizable {
    public static final MapCodec<FruitSaplingBlock> CODEC = createCodec(s -> new FruitSaplingBlock(s, "orange"));
    private static final VoxelShape SHAPE = Block.createCuboidShape(2, 0, 2, 14, 12, 14);
    private final String tree;

    public FruitSaplingBlock(Settings settings, String tree) {
        super(settings);
        this.tree = tree;
    }

    @Override
    public MapCodec<? extends PlantBlock> getCodec() {
        return CODEC;
    }

    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }

    @Override
    public void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (world.getLightLevel(pos.up()) >= 9 && random.nextInt(7) == 0) {
            tryGrow(world, pos, state, random);
        }
    }

    private void tryGrow(ServerWorld world, BlockPos pos, BlockState state, Random random) {
        Registry<ConfiguredFeature<?, ?>> reg = world.getRegistryManager().get(RegistryKeys.CONFIGURED_FEATURE);
        Optional<RegistryEntry.Reference<ConfiguredFeature<?, ?>>> feature = reg.getEntry(
                RegistryKey.of(RegistryKeys.CONFIGURED_FEATURE, FarmersRework.id(tree + "_tree")));
        if (feature.isEmpty()) return;
        world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NO_REDRAW);
        if (!feature.get().value().generate(world, world.getChunkManager().getChunkGenerator(), random, pos)) {
            world.setBlockState(pos, state, Block.NO_REDRAW);
        }
    }

    @Override
    public boolean isFertilizable(WorldView world, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public boolean canGrow(net.minecraft.world.World world, Random random, BlockPos pos, BlockState state) {
        return random.nextFloat() < 0.45f;
    }

    @Override
    public void grow(ServerWorld world, Random random, BlockPos pos, BlockState state) {
        tryGrow(world, pos, state, random);
    }
}
