package com.iamnotplaying.farmersrework;

import com.iamnotplaying.farmersrework.block.FarmCropBlock;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.fabricmc.fabric.api.registry.CompostingChanceRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradeOffers;
import net.minecraft.village.TradedItem;
import net.minecraft.village.VillagerProfession;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.GenerationStep;

import java.util.List;
import java.util.Optional;

public class FarmersRework implements ModInitializer {
    public static final String MOD_ID = "farmersrework";
    public static final RegistryKey<Enchantment> REPLENISH = RegistryKey.of(RegistryKeys.ENCHANTMENT, id("replenish"));
    public static final RegistryKey<Enchantment> BABY_CROPS = RegistryKey.of(RegistryKeys.ENCHANTMENT, id("baby_crops"));

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.init();
        ModItems.init();
        ModVillagers.init();
        registerMechanics();
        registerTrades();
        registerWorldgen();
        registerCompost();
    }

    // ---------------------------------------------------------------- mechanics

    static boolean hasEnchant(World world, ItemStack stack, RegistryKey<Enchantment> key) {
        if (stack.isEmpty()) return false;
        return world.getRegistryManager().get(RegistryKeys.ENCHANTMENT).getEntry(key)
                .map(e -> EnchantmentHelper.getLevel(e, stack) > 0).orElse(false);
    }

    /** Seed item for the crops we know how to replant (modded + the 4 vanilla ones). */
    static Item seedOf(Block b) {
        if (b instanceof FarmCropBlock f) return f.seed();
        if (b == Blocks.WHEAT) return Items.WHEAT_SEEDS;
        if (b == Blocks.CARROTS) return Items.CARROT;
        if (b == Blocks.POTATOES) return Items.POTATO;
        if (b == Blocks.BEETROOTS) return Items.BEETROOT_SEEDS;
        return null;
    }

    private void registerMechanics() {
        // Right-click harvest + replant (any hand item, main hand only)
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (player.isSpectator() || hand != Hand.MAIN_HAND) return ActionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            BlockState st = world.getBlockState(pos);
            if (!(st.getBlock() instanceof CropBlock crop) || !crop.isMature(st)) return ActionResult.PASS;
            Item seed = seedOf(crop);
            if (seed == null) return ActionResult.PASS;
            if (!(world instanceof ServerWorld sw)) return ActionResult.SUCCESS;
            List<ItemStack> drops = Block.getDroppedStacks(st, sw, pos, null, player, player.getMainHandStack());
            boolean replanted = false;
            for (ItemStack s : drops) {
                if (!replanted && s.isOf(seed)) {
                    s.decrement(1);
                    replanted = true;
                }
            }
            for (ItemStack s : drops) {
                if (!s.isEmpty()) Block.dropStack(world, pos, s);
            }
            if (replanted) {
                world.setBlockState(pos, crop.withAge(0), Block.NOTIFY_ALL);
            } else {
                world.breakBlock(pos, false);
            }
            world.playSound(null, pos, SoundEvents.BLOCK_CROP_BREAK, SoundCategory.BLOCKS, 1f, 1f);
            return ActionResult.SUCCESS;
        });

        // Baby Crops: block breaking of immature crops
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, be) -> {
            if (state.getBlock() instanceof CropBlock crop && !crop.isMature(state)
                    && hasEnchant(world, player.getMainHandStack(), BABY_CROPS)) {
                player.sendMessage(Text.translatable("message.farmersrework.baby_crop"), true);
                return false;
            }
            return true;
        });

        // Replenish: replant using one of the dropped seeds
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (!(state.getBlock() instanceof CropBlock crop) || !crop.isMature(state)) return;
            if (!hasEnchant(world, player.getMainHandStack(), REPLENISH)) return;
            Item seed = seedOf(crop);
            if (seed == null) return;
            List<ItemEntity> ents = world.getEntitiesByClass(ItemEntity.class, new Box(pos).expand(1.5),
                    e -> e.getStack().isOf(seed));
            if (ents.isEmpty()) return;
            BlockState fresh = crop.getDefaultState();
            if (!world.getBlockState(pos).isAir() || !fresh.canPlaceAt(world, pos)) return;
            ItemEntity ent = ents.get(0);
            ent.getStack().decrement(1);
            if (ent.getStack().isEmpty()) ent.discard();
            world.setBlockState(pos, fresh, Block.NOTIFY_ALL);
            world.playSound(null, pos, SoundEvents.ITEM_CROP_PLANT, SoundCategory.BLOCKS, 1f, 1f);
        });
    }

    // ------------------------------------------------------------------- trades

    private static TradeOffers.Factory sell(Item item, int count, int emeralds, int max, int xp) {
        return (e, r) -> new TradeOffer(new TradedItem(Items.EMERALD, emeralds), new ItemStack(item, count), max, xp, 0.05f);
    }

    private static TradeOffers.Factory buy(Item item, int count, int max, int xp) {
        return (e, r) -> new TradeOffer(new TradedItem(item, count), new ItemStack(Items.EMERALD, 1), max, xp, 0.05f);
    }

    private static TradeOffers.Factory book(RegistryKey<Enchantment> key, int cost) {
        return (e, r) -> {
            var entry = e.getWorld().getRegistryManager().get(RegistryKeys.ENCHANTMENT).getEntry(key);
            if (entry.isEmpty()) return null;
            ItemStack book = EnchantedBookItem.forEnchantment(new EnchantmentLevelEntry(entry.get(), 1));
            return new TradeOffer(new TradedItem(Items.EMERALD, cost), Optional.of(new TradedItem(Items.BOOK, 1)),
                    book, 12, 10, 0.2f);
        };
    }

    private void registerTrades() {
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.FARMER, 1, f -> {
            f.add(buy(ModItems.TOMATO, 22, 16, 2));
            f.add(buy(ModItems.ONION, 20, 16, 2));
            f.add(sell(ModItems.BAKED_TOMATO, 3, 1, 16, 1));
            f.add(sell(ModItems.TOMATO_SEEDS, 4, 1, 16, 1));
        });
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.FARMER, 2, f -> {
            f.add(buy(ModItems.LETTUCE, 20, 16, 5));
            f.add(buy(ModItems.CORN, 16, 16, 5));
            f.add(sell(ModItems.ONION_RINGS, 4, 1, 16, 5));
            f.add(sell(ModItems.LETTUCE_SEEDS, 4, 1, 16, 2));
            f.add(sell(ModItems.ONION_SEEDS, 4, 1, 16, 2));
        });
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.FARMER, 3, f -> {
            f.add(buy(ModItems.STRAWBERRY, 16, 16, 10));
            f.add(sell(ModItems.TOMATO_SOUP, 1, 2, 12, 10));
            f.add(sell(ModItems.GARDEN_SALAD, 1, 2, 12, 10));
            f.add(sell(ModItems.CORN_SEEDS, 4, 1, 16, 5));
            f.add(sell(ModItems.PUMPKIN_SOUP, 1, 2, 12, 10));
        });
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.FARMER, 4, f -> {
            f.add(sell(ModItems.ROASTED_CORN, 4, 1, 12, 15));
            f.add(sell(ModItems.PUMPKIN_COOKIES, 6, 1, 12, 15));
            f.add(sell(ModItems.STRAWBERRY_SEEDS, 4, 1, 16, 10));
            f.add(sell(ModItems.BEETROOT_CHIPS, 4, 1, 12, 15));
            f.add(sell(ModItems.RICH_FERTILIZER, 2, 3, 12, 15));
        });
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.FARMER, 5, f -> {
            f.add(sell(ModItems.CHERRY_PIE, 1, 3, 12, 30));
            f.add(sell(ModItems.FARMERS_BAG, 1, 8, 4, 30));
            f.add(sell(ModItems.GIANT_PUMPKIN_SEEDS, 1, 6, 8, 30));
            f.add(sell(ModItems.GIANT_MELON_SEEDS, 1, 6, 8, 30));
        });

        TradeOfferHelper.registerVillagerOffers(VillagerProfession.LIBRARIAN, 2, f -> f.add(book(REPLENISH, 14)));
        TradeOfferHelper.registerVillagerOffers(VillagerProfession.LIBRARIAN, 3, f -> f.add(book(BABY_CROPS, 18)));

        VillagerProfession o = ModVillagers.ORCHARDIST;
        TradeOfferHelper.registerVillagerOffers(o, 1, f -> {
            f.add(buy(ModItems.ORANGE, 20, 16, 2));
            f.add(buy(ModItems.CHERRY, 24, 16, 2));
            f.add(sell(ModItems.ORANGE_SAPLING, 1, 3, 8, 2));
        });
        TradeOfferHelper.registerVillagerOffers(o, 2, f -> {
            f.add(buy(ModItems.PEACH, 18, 16, 5));
            f.add(sell(ModItems.CHERRY_SAPLING, 1, 3, 8, 5));
            f.add(sell(ModItems.ORANGE_JUICE, 1, 2, 12, 5));
        });
        TradeOfferHelper.registerVillagerOffers(o, 3, f -> {
            f.add(sell(ModItems.PEACH_SAPLING, 1, 3, 8, 10));
            f.add(sell(ModItems.FRUIT_SALAD, 1, 3, 12, 10));
            f.add(sell(ModItems.ORANGE, 4, 1, 16, 5));
        });
        TradeOfferHelper.registerVillagerOffers(o, 4, f -> {
            f.add(sell(ModItems.MELON_JUICE, 1, 2, 12, 15));
            f.add(sell(ModItems.CHERRY, 6, 1, 16, 10));
            f.add(sell(ModItems.RICH_FERTILIZER, 2, 3, 12, 15));
        });
        TradeOfferHelper.registerVillagerOffers(o, 5, f -> {
            f.add(sell(ModItems.CHERRY_PIE, 1, 3, 12, 30));
            f.add(sell(ModItems.FARMERS_BAG, 1, 8, 4, 30));
        });
    }

    // ----------------------------------------------------------------- worldgen

    private void registerWorldgen() {
        for (String tree : new String[]{"orange", "cherry", "peach"}) {
            BiomeModifications.addFeature(
                    BiomeSelectors.includeByKey(BiomeKeys.PLAINS, BiomeKeys.SUNFLOWER_PLAINS, BiomeKeys.MEADOW,
                            BiomeKeys.FOREST, BiomeKeys.FLOWER_FOREST),
                    GenerationStep.Feature.VEGETAL_DECORATION,
                    RegistryKey.of(RegistryKeys.PLACED_FEATURE, id(tree + "_tree")));
        }
    }

    private void registerCompost() {
        for (Item i : new Item[]{ModItems.TOMATO, ModItems.LETTUCE, ModItems.ONION, ModItems.CORN, ModItems.STRAWBERRY,
                ModItems.ORANGE, ModItems.CHERRY, ModItems.PEACH, ModItems.TOMATO_SEEDS, ModItems.LETTUCE_SEEDS,
                ModItems.ONION_SEEDS, ModItems.CORN_SEEDS, ModItems.STRAWBERRY_SEEDS}) {
            CompostingChanceRegistry.INSTANCE.add(i, 0.65f);
        }
        for (Item i : new Item[]{ModItems.ORANGE_LEAVES, ModItems.CHERRY_LEAVES, ModItems.PEACH_LEAVES,
                ModItems.ORANGE_SAPLING, ModItems.CHERRY_SAPLING, ModItems.PEACH_SAPLING}) {
            CompostingChanceRegistry.INSTANCE.add(i, 0.3f);
        }
    }
}
