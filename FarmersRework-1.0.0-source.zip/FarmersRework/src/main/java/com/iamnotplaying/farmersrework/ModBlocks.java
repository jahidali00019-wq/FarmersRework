package com.iamnotplaying.farmersrework;

import com.iamnotplaying.farmersrework.block.*;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class ModBlocks {
    public static final List<Block> CUTOUT = new ArrayList<>();
    public static final List<Block> LEAVES = new ArrayList<>();

    private static <T extends Block> T reg(String name, T block) {
        return Registry.register(Registries.BLOCK, FarmersRework.id(name), block);
    }

    private static Block crop(String name, Supplier<Item> seeds) {
        Block b = reg(name, new FarmCropBlock(AbstractBlock.Settings.copy(Blocks.WHEAT), seeds));
        CUTOUT.add(b);
        return b;
    }

    private static Block giantCrop(String name, Supplier<Item> seeds, Supplier<Block> grown) {
        Block b = reg(name, new GiantCropBlock(AbstractBlock.Settings.copy(Blocks.WHEAT), seeds, grown));
        CUTOUT.add(b);
        return b;
    }

    private static Block leaves(String name, Supplier<Item> fruit) {
        Block b = reg(name, new FruitLeavesBlock(AbstractBlock.Settings.copy(Blocks.OAK_LEAVES), fruit));
        LEAVES.add(b);
        return b;
    }

    private static Block sapling(String name, String tree) {
        Block b = reg(name, new FruitSaplingBlock(AbstractBlock.Settings.copy(Blocks.OAK_SAPLING), tree));
        CUTOUT.add(b);
        return b;
    }

    public static final Block TOMATO_CROP = crop("tomato_crop", () -> ModItems.TOMATO_SEEDS);
    public static final Block LETTUCE_CROP = crop("lettuce_crop", () -> ModItems.LETTUCE_SEEDS);
    public static final Block ONION_CROP = crop("onion_crop", () -> ModItems.ONION_SEEDS);
    public static final Block CORN_CROP = crop("corn_crop", () -> ModItems.CORN_SEEDS);
    public static final Block STRAWBERRY_CROP = crop("strawberry_crop", () -> ModItems.STRAWBERRY_SEEDS);

    public static final Block GIANT_PUMPKIN = reg("giant_pumpkin", new Block(AbstractBlock.Settings.copy(Blocks.PUMPKIN)));
    public static final Block GIANT_MELON = reg("giant_melon", new Block(AbstractBlock.Settings.copy(Blocks.MELON)));
    public static final Block GIANT_PUMPKIN_CROP = giantCrop("giant_pumpkin_crop", () -> ModItems.GIANT_PUMPKIN_SEEDS, () -> GIANT_PUMPKIN);
    public static final Block GIANT_MELON_CROP = giantCrop("giant_melon_crop", () -> ModItems.GIANT_MELON_SEEDS, () -> GIANT_MELON);

    public static final Block ORANGE_LEAVES = leaves("orange_leaves", () -> ModItems.ORANGE);
    public static final Block CHERRY_LEAVES = leaves("cherry_leaves", () -> ModItems.CHERRY);
    public static final Block PEACH_LEAVES = leaves("peach_leaves", () -> ModItems.PEACH);
    public static final Block ORANGE_SAPLING = sapling("orange_sapling", "orange");
    public static final Block CHERRY_SAPLING = sapling("cherry_sapling", "cherry");
    public static final Block PEACH_SAPLING = sapling("peach_sapling", "peach");

    public static final Block FRUIT_CRATE = reg("fruit_crate", new Block(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS)));

    public static void init() {
    }
}
