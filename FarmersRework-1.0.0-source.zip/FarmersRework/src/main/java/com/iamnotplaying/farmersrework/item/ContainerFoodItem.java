package com.iamnotplaying.farmersrework.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

/** Food that returns its container (bowl / bottle) when eaten. */
public class ContainerFoodItem extends Item {
    private final Item container;
    private final UseAction action;

    public ContainerFoodItem(Settings settings, Item container, UseAction action) {
        super(settings);
        this.container = container;
        this.action = action;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return action;
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        ItemStack result = super.finishUsing(stack, world, user);
        if (user instanceof PlayerEntity p && p.isCreative()) return result;
        ItemStack back = new ItemStack(container);
        if (result.isEmpty()) return back;
        if (user instanceof PlayerEntity p && !p.getInventory().insertStack(back)) {
            p.dropItem(back, false);
        }
        return result;
    }
}
