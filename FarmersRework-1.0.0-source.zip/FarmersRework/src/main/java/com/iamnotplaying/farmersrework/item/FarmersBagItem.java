package com.iamnotplaying.farmersrework.item;

import com.iamnotplaying.farmersrework.ModItems;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Right-click to open a 27-slot bag that only accepts crops, seeds and fruit. */
public class FarmersBagItem extends Item {
    public FarmersBagItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack bag = user.getStackInHand(hand);
        if (!world.isClient) {
            BagInventory inv = new BagInventory(27);
            ContainerComponent comp = bag.getOrDefault(DataComponentTypes.CONTAINER, ContainerComponent.DEFAULT);
            comp.streamNonEmpty().forEach(s -> inv.addStack(s.copy()));
            inv.addListener(sender -> bag.set(DataComponentTypes.CONTAINER,
                    ContainerComponent.fromStacks(inv.getHeldStacks())));
            user.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                    (syncId, playerInv, p) -> GenericContainerScreenHandler.createGeneric9x3(syncId, playerInv, inv),
                    bag.getName()));
        }
        return TypedActionResult.success(bag, world.isClient());
    }

    static class BagInventory extends SimpleInventory {
        BagInventory(int size) {
            super(size);
        }

        @Override
        public boolean isValid(int slot, ItemStack stack) {
            return stack.isIn(ModItems.BAG_STORABLE);
        }
    }
}
