package com.iamnotplaying.farmersrework.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

import java.util.function.Supplier;

/** Leaves that slowly grow fruit (age 2 = ripe). Right-click to harvest. */
public class FruitLeavesBlock extends LeavesBlock {
    public static final IntProperty AGE = IntProperty.of("age", 0, 2);
    public static final MapCodec<FruitLeavesBlock> CODEC = createCodec(s -> new FruitLeavesBlock(s, () -> Items.APPLE));
    private final Supplier<Item> fruit;

    public FruitLeavesBlock(Settings settings, Supplier<Item> fruit) {
        super(settings);
        this.fruit = fruit;
        setDefaultState(getDefaultState().with(AGE, 0));
    }

    @Override
    public MapCodec<? extends LeavesBlock> getCodec() {
        return CODEC;
    }

    @Override
    public void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        super.appendProperties(builder);
        builder.add(AGE);
    }

    @Override
    public boolean hasRandomTicks(BlockState state) {
        return true;
    }

    @Override
    public void randomTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        super.randomTick(state, world, pos, random);
        BlockState now = world.getBlockState(pos);
        if (now.isOf(this) && now.get(AGE) < 2 && random.nextInt(8) == 0) {
            world.setBlockState(pos, now.with(AGE, now.get(AGE) + 1), Block.NOTIFY_LISTENERS);
        }
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (state.get(AGE) == 2) {
            if (!world.isClient) {
                Block.dropStack(world, pos, new ItemStack(fruit.get(), 1 + world.random.nextInt(2)));
                world.setBlockState(pos, state.with(AGE, 0), Block.NOTIFY_LISTENERS);
                world.playSound(null, pos, SoundEvents.BLOCK_SWEET_BERRY_BUSH_PICK_BERRIES, SoundCategory.BLOCKS, 1.0f, 1.0f);
            }
            return ActionResult.success(world.isClient);
        }
        return ActionResult.PASS;
    }
}
