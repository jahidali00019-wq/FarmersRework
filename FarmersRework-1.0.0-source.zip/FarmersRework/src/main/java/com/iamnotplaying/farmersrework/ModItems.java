package com.iamnotplaying.farmersrework;

import com.iamnotplaying.farmersrework.item.*;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.block.Block;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.text.Text;
import net.minecraft.util.UseAction;

import java.util.ArrayList;
import java.util.List;

public class ModItems {
    public static final List<Item> ALL = new ArrayList<>();
    public static final TagKey<Item> BAG_STORABLE = TagKey.of(RegistryKeys.ITEM, FarmersRework.id("bag_storable"));

    private static <T extends Item> T reg(String name, T item) {
        ALL.add(item);
        return Registry.register(Registries.ITEM, FarmersRework.id(name), item);
    }

    private static FoodComponent fc(int n, float s) {
        return new FoodComponent.Builder().nutrition(n).saturationModifier(s).build();
    }

    private static Item food(String n, int nu, float s) {
        return reg(n, new Item(new Item.Settings().food(fc(nu, s))));
    }

    private static Item bowl(String n, int nu, float s) {
        return reg(n, new ContainerFoodItem(new Item.Settings().maxCount(16).food(fc(nu, s)), Items.BOWL, UseAction.EAT));
    }

    private static Item drink(String n, int nu, float s) {
        return reg(n, new ContainerFoodItem(new Item.Settings().maxCount(16).food(fc(nu, s)), Items.GLASS_BOTTLE, UseAction.DRINK));
    }

    private static Item seed(String n, Block crop) {
        return reg(n, new AliasedBlockItem(crop, new Item.Settings()));
    }

    private static Item blockItem(String n, Block b) {
        return reg(n, new BlockItem(b, new Item.Settings()));
    }

    // Seeds
    public static final Item TOMATO_SEEDS = seed("tomato_seeds", ModBlocks.TOMATO_CROP);
    public static final Item LETTUCE_SEEDS = seed("lettuce_seeds", ModBlocks.LETTUCE_CROP);
    public static final Item ONION_SEEDS = seed("onion_seeds", ModBlocks.ONION_CROP);
    public static final Item CORN_SEEDS = seed("corn_seeds", ModBlocks.CORN_CROP);
    public static final Item STRAWBERRY_SEEDS = seed("strawberry_seeds", ModBlocks.STRAWBERRY_CROP);
    public static final Item GIANT_PUMPKIN_SEEDS = seed("giant_pumpkin_seeds", ModBlocks.GIANT_PUMPKIN_CROP);
    public static final Item GIANT_MELON_SEEDS = seed("giant_melon_seeds", ModBlocks.GIANT_MELON_CROP);

    // Crops & fruits
    public static final Item TOMATO = food("tomato", 3, 0.4f);
    public static final Item LETTUCE = food("lettuce", 2, 0.3f);
    public static final Item ONION = food("onion", 2, 0.3f);
    public static final Item CORN = food("corn", 3, 0.4f);
    public static final Item STRAWBERRY = food("strawberry", 2, 0.3f);
    public static final Item ORANGE = food("orange", 4, 0.4f);
    public static final Item CHERRY = food("cherry", 2, 0.3f);
    public static final Item PEACH = food("peach", 4, 0.5f);

    // Cooked / crafted foods
    public static final Item TOMATO_SOUP = bowl("tomato_soup", 8, 0.7f);
    public static final Item GARDEN_SALAD = bowl("garden_salad", 8, 0.7f);
    public static final Item FRUIT_SALAD = bowl("fruit_salad", 7, 0.6f);
    public static final Item PUMPKIN_SOUP = bowl("pumpkin_soup", 8, 0.7f);
    public static final Item ROASTED_CORN = food("roasted_corn", 7, 0.8f);
    public static final Item BAKED_TOMATO = food("baked_tomato", 6, 0.7f);
    public static final Item ONION_RINGS = food("onion_rings", 6, 0.6f);
    public static final Item CHERRY_PIE = food("cherry_pie", 10, 0.8f);
    public static final Item PUMPKIN_COOKIES = food("pumpkin_cookies", 3, 0.4f);
    public static final Item BEETROOT_CHIPS = food("beetroot_chips", 4, 0.5f);
    public static final Item ORANGE_JUICE = drink("orange_juice", 5, 0.5f);
    public static final Item MELON_JUICE = drink("melon_juice", 5, 0.5f);

    // Tools
    public static final Item RICH_FERTILIZER = reg("rich_fertilizer", new FertilizerItem(new Item.Settings()));
    public static final Item FARMERS_BAG = reg("farmers_bag", new FarmersBagItem(new Item.Settings().maxCount(1)));

    // Block items
    public static final Item GIANT_PUMPKIN = blockItem("giant_pumpkin", ModBlocks.GIANT_PUMPKIN);
    public static final Item GIANT_MELON = blockItem("giant_melon", ModBlocks.GIANT_MELON);
    public static final Item ORANGE_LEAVES = blockItem("orange_leaves", ModBlocks.ORANGE_LEAVES);
    public static final Item CHERRY_LEAVES = blockItem("cherry_leaves", ModBlocks.CHERRY_LEAVES);
    public static final Item PEACH_LEAVES = blockItem("peach_leaves", ModBlocks.PEACH_LEAVES);
    public static final Item ORANGE_SAPLING = blockItem("orange_sapling", ModBlocks.ORANGE_SAPLING);
    public static final Item CHERRY_SAPLING = blockItem("cherry_sapling", ModBlocks.CHERRY_SAPLING);
    public static final Item PEACH_SAPLING = blockItem("peach_sapling", ModBlocks.PEACH_SAPLING);
    public static final Item FRUIT_CRATE = blockItem("fruit_crate", ModBlocks.FRUIT_CRATE);

    public static void init() {
        Registry.register(Registries.ITEM_GROUP, FarmersRework.id("main"), FabricItemGroup.builder()
                .displayName(Text.translatable("itemGroup.farmersrework.main"))
                .icon(() -> new ItemStack(TOMATO))
                .entries((ctx, entries) -> ALL.forEach(entries::add))
                .build());
    }
}
